package lang;
import java.util.ArrayList;

public class Main1 {
    public static void main(String[] args) {
        // Example of using ArrayList class (imported explicitly)
        ArrayList<String> myList = new ArrayList<>();
        
        // Adding elements to the ArrayList
        myList.add("Apple");
        myList.add("Banana");
        myList.add("Orange");
        
        // Displaying elements of the ArrayList
        System.out.println("Elements of the ArrayList:");
        for (String element : myList) {
            System.out.println(element);
        }
    }
}


