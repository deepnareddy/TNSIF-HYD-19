package lang;

import java.awt.Button;
import java.awt.Frame;

public class Awt {
    public static void main(String[] args) {
        // Create a frame
        Frame frame = new Frame("Simple Button Example");

        // Create a button
        Button button = new Button("Click Me");

        // Add button to the frame
        frame.add(button);

        // Set frame size and make it visible
        frame.setSize(200, 100);
        frame.setVisible(true);
    }
}
