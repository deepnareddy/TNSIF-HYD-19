package lang;
import java.lang.String;

public class Main {
    public static void main(String[] args) {
        // Example of using String class (imported explicitly)
        String str = "Hello, world!";
        System.out.println("Length of the string: " + str.length());
    }
}
