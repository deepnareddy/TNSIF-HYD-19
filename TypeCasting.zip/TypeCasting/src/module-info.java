/**
 * 
 */
/**
 * 
 */
module TypeCasting {
}