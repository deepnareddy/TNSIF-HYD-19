/**
 * 
 */
/**
 * 
 */
module CrudOperations {
	requires java.sql;
}