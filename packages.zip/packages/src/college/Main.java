package college;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cse c1=new Cse();
		c1.internals();
		c1.externals();
		c1.mid();
		Ece e1=new Ece();
		e1.internals();
		e1.externals();
		e1.mid();
		Eee e2=new Eee();
		e2.internals();
		e2.externals();
		e2.mid();

	}

}
