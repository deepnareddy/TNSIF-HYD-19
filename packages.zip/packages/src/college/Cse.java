package college;

 class Cse {
	public void internals() {
		System.out.println("total marks are 30");
	}
	public void externals() {
		System.out.println("total marks are 50");
	}
    public void mid() {
    	System.out.println("total marks are 100");
    }
}
 class Ece {
		public void internals() { 
			System.out.println("total marks are 10");
		}
		public void externals() {
			System.out.println("total marks are 20");
		}
		public void mid() {
			System.out.println("total marks are 40");
		}
 }
 class Eee {
		public void internals() {
			System.out.println("total marks are 10");
		}
		public void externals() {
			System.out.println("total marks are 80");
		}
		public void mid() {
			System.out.println("total marks are 30");
		}

	}

