package com.si;

public class Normal {
	int a=23;
	static int b=10;
	void display() {
		System.out.println("numbers");
	}
	static String display1() {
		return "numbers";
	}

}
