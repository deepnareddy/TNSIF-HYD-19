package com.si;

public class AccessClass {

	public static void main(String[] args) {
		Normal n1=new Normal();
		System.out.println(n1.a);
		n1.display();
		System.out.println(Normal.b);
		System.out.println(Normal.display1());
		// TODO Auto-generated method stub

	}

}
