package com;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor myCar = new Constructor();
		myCar.setMake("Toyota");
        myCar.setModel("Camry");
        myCar.setYear(2022);

        // Accessing the properties using getter methods
        System.out.println("Make: " + myCar.getMake());
        System.out.println("Model: " + myCar.getModel());
        System.out.println("Year: " + myCar.getYear());

	}

}
