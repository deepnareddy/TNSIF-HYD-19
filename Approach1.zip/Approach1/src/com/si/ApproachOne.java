package com.si;

public class ApproachOne {
	int a=100;
	static int b=10;
	void display() {
		System.out.println("numbers");
	}
	static String display1() {
		return "numbers";
	}

	public static void main(String[] args) {
		ApproachOne a1=new ApproachOne();
		System.out.println(a1.a);
		a1.display();
		System.out.println(ApproachOne.b);
		System.out.println(ApproachOne.display1());
		// TODO Auto-generated method stub

	}

}
