package com.oop;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encapsulation e3 = new Encapsulation();
		e3.setAge(30);
		e3.setGender("female");
		e3.setName("anjali");
		
		System.out.println(e3.getAge());
		System.out.println(e3.getGender());
		System.out.println(e3.getName());

	}

}
